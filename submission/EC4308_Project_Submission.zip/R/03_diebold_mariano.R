# =============================================================================
# 03_diebold_mariano.R -- Diebold-Mariano (1995) test of equal predictive
# accuracy, HAC (Newey-West) robust
# =============================================================================
# Loss differential:  d_t = |e1_t|^p - |e2_t|^p
#   p = 2  -> RMSE basis (squared-error loss)
#   p = 1  -> MAE basis (absolute-error loss)
#
# H0: E[d_t] = 0 (equal predictive accuracy)
# H1 (one-sided, "less"): E[d_t] < 0  ->  f1 is MORE accurate than f2
#
# The long-run variance of d_t is estimated with a Newey-West (Bartlett)
# kernel using the conventional lag = h - 1. Estimated nonlinear models'
# loss differentials need not be exactly MA(h-1); this is a bandwidth choice,
# not a guarantee of inference validity for every data-generating process.
#
# We use T-normalized autocovariances and asymptotic normal p-values, with
# no Harvey small-sample correction. Do not expect numerical identity to
# forecast::dm.test, which uses a different finite-sample convention.
# R/99 independently checks the Bartlett covariance as a quadratic form.
# =============================================================================

hac_var_mean <- function(x, lag = 0L) {
  # Newey-West variance of the SAMPLE MEAN of a series (LRV / T).
  T  <- length(x)
  stopifnot(is.numeric(x), all(is.finite(x)), T >= 2L,
            length(lag) == 1L, is.finite(lag), lag >= 0L,
            lag == as.integer(lag), lag < T)
  xc <- x - mean(x)
  g0 <- sum(xc^2) / T
  if (lag <= 0L || T < lag + 1L) return(g0 / T)

  s <- 0
  for (k in seq_len(lag)) {
    gk <- sum(xc[(k + 1L):T] * xc[seq_len(T - k)]) / T
    s  <- s + (1 - k / (lag + 1)) * 2 * gk
  }
  (g0 + s) / T
}

dm_test <- function(actual, f1, f2, power = 2L, h = 1L,
                    alternative = c("two.sided", "less", "greater")) {
  alternative <- match.arg(alternative)
  stopifnot(is.numeric(actual), is.numeric(f1), is.numeric(f2),
            all(is.finite(actual)), all(is.finite(f1)), all(is.finite(f2)),
            length(actual) == length(f1), length(actual) == length(f2),
            length(power) == 1L, power %in% c(1L, 2L),
            length(h) == 1L, is.finite(h), h == as.integer(h),
            h >= 1L, h <= length(actual))

  e1 <- actual - f1
  e2 <- actual - f2
  d  <- abs(e1)^power - abs(e2)^power
  T  <- length(d)
  if (T < 2L) stop("DM test needs at least 2 observations.", call. = FALSE)

  dbar <- mean(d)
  if (all(d == 0)) {
    # identical forecasts: no loss differential, zero statistic
    stat <- 0
  } else {
    v <- hac_var_mean(d, lag = h - 1L)
    if (!is.finite(v) || v <= 0) {
      stop("DM loss differential has no positive estimated variance.",
           call. = FALSE)
    }
    stat <- dbar / sqrt(v)
  }

  p <- switch(
    alternative,
    two.sided = 2 * stats::pnorm(-abs(stat)),
    less      = stats::pnorm(stat),      # H1: f1 more accurate (d < 0)
    greater   = 1 - stats::pnorm(stat)   # H1: f2 more accurate (d > 0)
  )

  structure(
    list(statistic     = stat,
         p.value       = p,
         alternative   = alternative,
         loss          = if (power == 2L) "squared (RMSE basis)" else "absolute (MAE basis)",
         mean_loss_diff = dbar,
         n             = T,
         horizon       = h,
         h0            = "equal predictive accuracy"),
    class = "dm_test"
  )
}

print.dm_test <- function(x, ...) {
  cat("Diebold-Mariano test (HAC, Newey-West lag", x$horizon - 1L, ")\n")
  cat("  Loss:", x$loss, "\n")
  cat("  DM statistic:", format(x$statistic, digits = 4), "\n")
  cat("  p-value (", x$alternative, "): ", format(x$p.value, digits = 4),
      "\n", sep = "")
  cat("  n:", x$n, "| mean loss diff:", format(x$mean_loss_diff, digits = 4), "\n")
  invisible(x)
}
